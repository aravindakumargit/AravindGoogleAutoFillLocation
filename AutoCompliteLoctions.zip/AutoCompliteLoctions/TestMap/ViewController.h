//
//  ViewController.h
//  TestMap
//
//  Created by Aravindhakumar on 27/09/16.
//  Copyright © 2016 Aravindhakumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<UITextFieldDelegate,UISearchBarDelegate,
UISearchControllerDelegate,
CLLocationManagerDelegate,
UITableViewDataSource,
UITableViewDelegate>{
@private
    CGRect _searchTableViewRect;
    
}

@property (strong, nonatomic) CLLocationManager *locationManager;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (strong, nonatomic) UISearchController *searchController;
@property (strong, nonatomic) NSArray *resultstest;
@property(nonatomic, retain) IBOutlet UITextField *txtsel;
@end

